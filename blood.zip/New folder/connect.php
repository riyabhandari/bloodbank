<?php
	$host="localhost";
	$user="root";
	$password="riya123";
	$db="bloodbank";
	$conn=new mysqli($host,$user,$password,$db) or die("cannot cannot");
	
?>