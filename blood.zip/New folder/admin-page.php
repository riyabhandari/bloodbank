<!DOCTYPE html>
<html>
<head>
	<title>ADMIN PAGE</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id="total">
		<div id="inside">
			<div id="header" ><h2 align="center">BLOOD BANK MANAGEMENT SYSTEM</h2></div>
			<div id="body"><br><br>
				<h1 style="margin-left: 120px">ADMIN MODE</h1>
				<br><br>
				<ul>
					<li><a href="donor-list.php">Donor List</a></li>
				</ul>
				<br><br>
				<ul>
					<li><a href="blood-stock.php">Blood Availability</a></li>
				</ul>
				
			</div>
			<div id="footer"><h4 align="center">Copyright@BloodBankManagementSystem</h4></div>
		</div>
	</div>		
</body>
</html>